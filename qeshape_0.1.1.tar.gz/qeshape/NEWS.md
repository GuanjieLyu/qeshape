# qeshape 0.1.1

- Rename the package from `qecal` to `qeshape` before public release.
  Load it with `library(qeshape)`; the exported `qe_*` functions are unchanged.
- Count numerical bootstrap ties consistently under positive rescaling.
  Apply the rounding tolerance on the asymmetry-amplitude scale, preserving
  comparisons on very short trim intervals, and expose the actual p-value
  cutoff as `p.value.threshold`.
- Add exact small-sample tie checks and nondefault RNG/S3 regression tests.
  Make installation instructions work from a repository checkout and preserve
  the previous PDF manual if rebuilding fails.
- Test the declared minimum R version in CI, fail on check notes, and pin
  workflow actions with automated dependency updates.

# qeshape 0.1.0

Initial release.

- Add a PDF reference manual generated from the package help files, with a
  reproducible build command and a worked overview. Clarify shape regularity
  and the distinction between population symmetry and empirical knot values.
- Estimate empirical quantile-expectile calibration and asymmetry curves.
- Construct simultaneous empirical-bootstrap confidence bands on a fixed
  trimmed interval.
- Test symmetry with centered-bootstrap Cramer-von Mises and supremum
  statistics using exact empirical step-function calculations.
- Provide plotting, prediction, printing, and data-frame methods for curves
  and bands, with standard `htest` output for symmetry tests.
- Include reproducible examples, mathematical regression tests, and automated
  package checks across Linux, Windows, and macOS.

.qe_band_grid <- function(sample, trim) {
  knots <- sample$breaks
  sort(unique(c(trim, knots[knots > trim & knots < 1 - trim], 1 - trim)))
}

.qe_symmetry_grid <- function(sample, trim) {
  knots <- sample$breaks
  interior <- knots[knots > trim & knots < 0.5]
  boundaries <- c(trim, interior, 0.5)
  # Work directly with the ranks on each open cell: a floating-point midpoint
  # can round to an endpoint when trim is extremely close to a knot.
  inside <- findInterval(boundaries[-length(boundaries)], knots) + 1L
  list(boundary.ranks = .qe_ranks(boundaries, sample),
       boundary.reflected = .qe_ranks(boundaries, sample, reflected = TRUE),
       interior.ranks = inside, interior.reflected = sample$n - inside + 1L,
       widths = diff(boundaries))
}

# Only a single resample is kept in memory. The length-B scalar statistics
# are retained so Monte Carlo quantiles and p-values remain auditable.
.qe_bootstrap <- function(sample, B, seed, statistic) {
  .qe_with_seed(seed, {
    result <- numeric(B)
    prob <- rep.int(1 / sample$n, sample$n)
    for (b in seq_len(B)) {
      counts <- stats::rmultinom(1L, size = sample$n, prob = prob)[, 1L]
      result[b] <- statistic(.qe_levels(sample, counts))
    }
    result
  })
}

# See man/qe_band.Rd for the public contract.
qe_band <- function(x, trim = 0.05, conf.level = 0.95, B = 999L,
                    seed = NULL, na.rm = FALSE) {
  .qe_boot_args(trim, B, seed)
  .qe_number(conf.level, "conf.level", 0, 1, open = TRUE)
  if (1 - trim >= 1) {
    stop("`trim` is too small to form an interior band endpoint in double precision.",
         call. = FALSE)
  }
  sample <- .qe_sample(x, na.rm, inference = TRUE)
  probs <- .qe_band_grid(sample, trim)
  fit <- .qe_curve_object(sample, probs, match.call())
  ranks <- .qe_ranks(probs, sample)
  root_n <- sqrt(sample$n)
  observed <- fit$calibration
  draws <- .qe_bootstrap(sample, B, seed, function(levels) {
    root_n * max(abs(levels[ranks] - observed))
  })
  critical <- unname(stats::quantile(draws, probs = conf.level, type = 1))
  fit$lower <- pmax(0, observed - critical / root_n)
  fit$upper <- pmin(1, observed + critical / root_n)
  fit$trim <- trim
  fit$conf.level <- conf.level
  fit$B <- as.integer(B)
  fit["seed"] <- list(seed)
  fit$critical.value <- critical
  fit$half.width <- critical / root_n
  fit$bootstrap.statistics <- draws
  class(fit) <- c("qe_band", "qe_curve")
  fit
}

predict.qe_band <- function(object, probs = object$probabilities, ...) {
  .qe_no_dots(...)
  probs <- .qe_probs(probs)
  if (any(probs < object$trim | probs > 1 - object$trim)) {
    stop("Band predictions must lie in [trim, 1 - trim].", call. = FALSE)
  }
  ranks <- .qe_ranks(probs, object$.sample)
  tau <- .qe_levels(object$.sample)[ranks]
  data.frame(probability = probs, quantile = object$.sample$x[ranks],
             calibration = tau, lower = pmax(0, tau - object$half.width),
             upper = pmin(1, tau + object$half.width))
}

as.data.frame.qe_band <- function(x, row.names = NULL, optional = FALSE, ...) {
  data.frame(probability = x$probabilities, quantile = x$quantiles,
             calibration = x$calibration, lower = x$lower, upper = x$upper,
             row.names = row.names, check.names = !optional, ...)
}

# See man/qe_symmetry_test.Rd for the public contract.
qe_symmetry_test <- function(x, method = c("cvm", "ks"), trim = 0.05,
                             B = 999L, seed = NULL, na.rm = FALSE) {
  method <- match.arg(method)
  .qe_boot_args(trim, B, seed)
  sample <- .qe_sample(x, na.rm, inference = TRUE)
  grid <- .qe_symmetry_grid(sample, trim)
  ranks <- grid$interior.ranks
  reflected <- grid$interior.reflected
  if (method == "ks") {
    ranks <- c(ranks, grid$boundary.ranks)
    reflected <- c(reflected, grid$boundary.reflected)
  }
  levels <- .qe_levels(sample)
  observed_D <- levels[ranks] + levels[reflected] - 1
  functional <- if (method == "cvm") {
    function(d) sample$n * sum(grid$widths * d^2)
  } else {
    function(d) sqrt(sample$n) * max(abs(d))
  }
  observed <- functional(observed_D)
  draws <- .qe_bootstrap(sample, B, seed, function(levels) {
    centered <- levels[ranks] + levels[reflected] - 1 - observed_D
    functional(centered)
  })
  # Count numerical ties as exceedances. Compare on the scale of D (its RMS
  # for CvM, supremum for KS), so tolerance does not depend on n or interval
  # width. A raw-statistic absolute tolerance would erase tiny-trim differences.
  comparison_scale <- if (method == "cvm") sample$n * (0.5 - trim) else
    sqrt(sample$n)
  amplitude <- if (method == "cvm") sqrt(observed / comparison_scale) else
    observed / comparison_scale
  cutoff <- max(0, amplitude - 64 * .Machine$double.eps)
  threshold <- comparison_scale * if (method == "cvm") cutoff^2 else cutoff
  label <- if (method == "cvm") "CvM" else "KS"
  structure(list(statistic = stats::setNames(observed, label),
                 parameter = c(n = sample$n, B = B, trim = trim),
                 p.value = (1 + sum(draws >= threshold)) / (B + 1),
                 p.value.threshold = threshold,
                 method = paste("Quantile-expectile", label,
                                "symmetry test (centered empirical bootstrap)"),
                 alternative = paste("the distribution is not symmetric on",
                                     "the trimmed calibration interval"),
                 data.name = paste(deparse(substitute(x)), collapse = " "),
                 bootstrap.statistics = draws, n = sample$n,
                 omitted = sample$omitted, B = as.integer(B), trim = trim,
                 seed = seed, call = match.call()),
            class = c("qe_symmetry_test", "htest"))
}

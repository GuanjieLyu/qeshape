# Calibration at every order statistic, for the original sample or an ordinary
# empirical bootstrap resample represented by multinomial multiplicities.
.qe_levels <- function(sample, counts = NULL) {
  n <- sample$n
  if (sample$constant) return(rep.int(0.5, n))
  if (is.null(counts)) {
    cumulative <- seq_len(n)
    gaps <- sample$gaps
  } else {
    positive <- counts > 0L
    support <- sample$x[positive]
    if (support[1L] == support[length(support)]) return(rep.int(0.5, n))
    cumulative <- cumsum(counts[positive])
    # Recompute the scale on the active support: a resample can omit an
    # extreme observation that otherwise dwarfs all its remaining spacings.
    gaps <- .qe_spacings(support)
  }
  m <- length(cumulative)
  left_mass <- cumulative[-m]
  # At order position k, L_k = sum_{j<k} C_j * (x[j+1]-x[j])/n.
  # U_k is the reverse sum with n-C_j. The common scale and n cancel.
  lower <- c(0, cumsum(left_mass * gaps))
  upper <- c(rev(cumsum(rev((n - left_mass) * gaps))), 0)
  total <- lower + upper
  levels <- rep.int(0.5, m)
  positive <- total > 0
  levels[positive] <- lower[positive] / total[positive]
  if (is.null(counts)) return(levels)
  positions <- findInterval(seq_len(n) - 1L, cumulative) + 1L
  levels[positions]
}

.qe_curve_object <- function(sample, probs, call) {
  ranks <- .qe_ranks(probs, sample)
  structure(list(probabilities = probs,
                 calibration = .qe_levels(sample)[ranks],
                 quantiles = sample$x[ranks], n = sample$n,
                 omitted = sample$omitted, call = call, .sample = sample),
            class = "qe_curve")
}

# See man/qe_curve.Rd for the public contract.
qe_curve <- function(x, probs = (5:95) / 100, na.rm = FALSE) {
  sample <- .qe_sample(x, na.rm)
  probs <- .qe_probs(probs)
  .qe_curve_object(sample, probs, match.call())
}

.qe_asymmetry_values <- function(levels, sample, probs) {
  levels[.qe_ranks(probs, sample)] +
    levels[.qe_ranks(probs, sample, reflected = TRUE)] - 1
}

# See man/qe_asymmetry.Rd for the public contract.
qe_asymmetry <- function(x, probs = (5:50) / 100, na.rm = FALSE) {
  sample <- .qe_sample(x, na.rm)
  probs <- .qe_probs(probs, asymmetry = TRUE)
  structure(list(probabilities = probs,
                 asymmetry = .qe_asymmetry_values(.qe_levels(sample), sample, probs),
                 n = sample$n, omitted = sample$omitted,
                 call = match.call(), .sample = sample),
            class = "qe_asymmetry")
}

predict.qe_curve <- function(object, probs = object$probabilities, ...) {
  .qe_no_dots(...)
  probs <- .qe_probs(probs)
  .qe_levels(object$.sample)[.qe_ranks(probs, object$.sample)]
}

predict.qe_asymmetry <- function(object, probs = object$probabilities, ...) {
  .qe_no_dots(...)
  probs <- .qe_probs(probs, asymmetry = TRUE)
  .qe_asymmetry_values(.qe_levels(object$.sample), object$.sample, probs)
}

as.data.frame.qe_curve <- function(x, row.names = NULL, optional = FALSE, ...) {
  data.frame(probability = x$probabilities, quantile = x$quantiles,
             calibration = x$calibration, row.names = row.names,
             check.names = !optional, ...)
}

as.data.frame.qe_asymmetry <- function(x, row.names = NULL, optional = FALSE, ...) {
  data.frame(probability = x$probabilities, asymmetry = x$asymmetry,
             row.names = row.names, check.names = !optional, ...)
}

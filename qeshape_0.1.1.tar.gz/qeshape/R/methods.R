.qe_print_table <- function(x) {
  print(x[seq_len(min(6L, nrow(x))), , drop = FALSE], row.names = FALSE)
  if (nrow(x) > 6L) {
    cat("... ", nrow(x) - 6L,
        " more rows; use as.data.frame() to extract all values.\n", sep = "")
  }
}

print.qe_curve <- function(x, ...) {
  .qe_no_dots(...)
  cat("Quantile-expectile calibration curve\n")
  cat("n =", x$n, " | probabilities =", length(x$probabilities), "\n")
  if (x$omitted) cat("Missing observations removed:", x$omitted, "\n")
  .qe_print_table(as.data.frame(x))
  invisible(x)
}

print.qe_asymmetry <- function(x, ...) {
  .qe_no_dots(...)
  cat("Quantile-expectile asymmetry curve\n")
  cat("n =", x$n, " | probabilities =", length(x$probabilities), "\n")
  if (x$omitted) cat("Missing observations removed:", x$omitted, "\n")
  .qe_print_table(as.data.frame(x))
  invisible(x)
}

print.qe_band <- function(x, ...) {
  .qe_no_dots(...)
  cat(format(100 * x$conf.level), "% simultaneous calibration band\n", sep = "")
  cat("n =", x$n, " | B =", x$B, " | interval = [", x$trim, ", ",
      1 - x$trim, "]\n", sep = " ")
  cat("Unclipped half-width:", format(x$half.width, digits = 5L), "\n")
  if (x$omitted) cat("Missing observations removed:", x$omitted, "\n")
  .qe_print_table(as.data.frame(x))
  invisible(x)
}

.qe_plot_grid <- function(x) {
  limits <- range(x$probabilities)
  knots <- x$.sample$breaks
  sort(unique(c(limits, knots[knots > limits[1L] & knots < limits[2L]])))
}

.qe_plot_frame <- function(probs, values, xlab, ylab, main, ylim, dots) {
  defaults <- list(x = probs, y = values, type = "n", xlab = xlab,
                   ylab = ylab, main = main, ylim = ylim)
  # User-supplied plotting-region options, e.g. xlim and axes, remain available.
  for (name in names(dots)) defaults[[name]] <- dots[[name]]
  do.call(graphics::plot, defaults)
}

plot.qe_curve <- function(x, xlab = NULL, ylab = NULL, main = NULL,
                          col = "#236B8E", lwd = 2, ...) {
  probs <- .qe_plot_grid(x)
  values <- predict.qe_curve(x, probs)
  .qe_plot_frame(probs, values,
                 if (is.null(xlab)) "Quantile probability" else xlab,
                 if (is.null(ylab)) "Calibration level" else ylab,
                 if (is.null(main)) "Quantile-expectile calibration" else main,
                 c(0, 1), list(...))
  graphics::lines(probs, values, type = if (length(probs) > 1L) "S" else "p",
                  col = col, lwd = lwd)
  invisible(x)
}

plot.qe_asymmetry <- function(x, xlab = NULL, ylab = NULL, main = NULL,
                              col = "#236B8E", lwd = 2, ...) {
  boundaries <- .qe_plot_grid(x)
  values <- predict.qe_asymmetry(x, boundaries)
  left <- boundaries[-length(boundaries)]
  right <- boundaries[-1L]
  levels <- .qe_levels(x$.sample)
  inside <- findInterval(left, x$.sample$breaks) + 1L
  middle <- levels[inside] + levels[x$n - inside + 1L] - 1
  limits <- range(c(0, values, middle))
  if (diff(limits) == 0) limits <- c(-0.05, 0.05)
  .qe_plot_frame(boundaries, values,
                 if (is.null(xlab)) "Quantile probability" else xlab,
                 if (is.null(ylab)) "Calibration asymmetry" else ylab,
                 if (is.null(main)) "Asymmetry about an unspecified center" else main,
                 limits, list(...))
  graphics::abline(h = 0, lty = 3L, col = "grey60")
  # The two reflected steps have opposite orientations. Knot values can differ
  # from both open-cell values, so draw them explicitly instead of interpolating.
  if (length(middle)) graphics::segments(left, middle, right, middle, col = col, lwd = lwd)
  graphics::points(boundaries, values, pch = 16L, cex = 0.45, col = col)
  invisible(x)
}

.qe_stairs <- function(probs, values) {
  n <- length(probs)
  if (n == 1L) return(list(x = probs, y = values))
  list(x = c(rep(probs[-n], each = 2L), probs[n]),
       y = c(values[1L], rep(values[-1L], each = 2L)))
}

plot.qe_band <- function(x, xlab = NULL, ylab = NULL, main = NULL,
                         col = "#236B8E", lwd = 2,
                         fill = grDevices::adjustcolor(col, alpha.f = 0.18), ...) {
  probs <- .qe_plot_grid(x)
  values <- predict.qe_band(x, probs)
  .qe_plot_frame(probs, values$calibration,
                 if (is.null(xlab)) "Quantile probability" else xlab,
                 if (is.null(ylab)) "Calibration level" else ylab,
                 if (is.null(main)) paste0(100 * x$conf.level,
                                           "% simultaneous calibration band") else main,
                 c(0, 1), list(...))
  lower <- .qe_stairs(probs, values$lower)
  upper <- .qe_stairs(probs, values$upper)
  graphics::polygon(c(lower$x, rev(upper$x)), c(lower$y, rev(upper$y)),
                    col = fill, border = NA)
  graphics::lines(probs, values$calibration, type = "S", col = col, lwd = lwd)
  invisible(x)
}

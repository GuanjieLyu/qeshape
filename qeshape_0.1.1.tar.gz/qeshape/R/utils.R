# Input checks are shared so estimation and inference use the same sample.
.qe_flag <- function(x, name) {
  if (!is.logical(x) || length(x) != 1L || is.na(x)) {
    stop("`", name, "` must be TRUE or FALSE.", call. = FALSE)
  }
}

.qe_number <- function(x, name, lower, upper, open = FALSE,
                       integer = FALSE) {
  valid <- is.numeric(x) && !is.complex(x) && !is.object(x) &&
    is.null(dim(x)) && length(x) == 1L && is.finite(x)
  if (valid) {
    valid <- if (open) x > lower && x < upper else x >= lower && x <= upper
    if (integer) valid <- valid && x == floor(x)
  }
  if (!valid) {
    interval <- if (open) paste0("(", lower, ", ", upper, ")") else
      paste0("[", lower, ", ", upper, "]")
    stop("`", name, "` must be a finite ",
         if (integer) "integer" else "number", " in ", interval, ".",
         call. = FALSE)
  }
  invisible(NULL)
}

.qe_probs <- function(probs, asymmetry = FALSE) {
  if (!is.numeric(probs) || is.complex(probs) || is.object(probs) ||
      !is.null(dim(probs)) || !length(probs) || any(!is.finite(probs)) ||
      any(probs <= 0 | probs >= 1) ||
      (asymmetry && any(probs > 0.5))) {
    stop("`probs` must be a nonempty numeric vector in ",
         if (asymmetry) "(0, 0.5]." else "(0, 1).", call. = FALSE)
  }
  as.numeric(probs)
}

.qe_sample <- function(x, na.rm, inference = FALSE) {
  .qe_flag(na.rm, "na.rm")
  if (!is.numeric(x) || is.complex(x) || is.object(x) ||
      !is.null(dim(x))) {
    stop("`x` must be a real numeric vector.", call. = FALSE)
  }
  omitted <- sum(is.na(x))
  if (omitted && !na.rm) {
    stop("`x` contains missing values; use `na.rm = TRUE` to remove them.",
         call. = FALSE)
  }
  if (na.rm) x <- x[!is.na(x)]
  if (!length(x)) stop("`x` must contain at least one observation.", call. = FALSE)
  if (any(!is.finite(x))) stop("`x` must contain only finite values.", call. = FALSE)
  n <- length(x)
  if (n > .Machine$integer.max) {
    stop("Long vectors are not supported.", call. = FALSE)
  }
  x <- sort(as.numeric(x))
  gaps <- diff(x)
  constant <- !length(gaps) || all(gaps == 0)
  if (inference && (n < 2L || constant)) {
    stop("Inference requires at least two observations and a nonconstant sample.",
         call. = FALSE)
  }
  if (!constant) gaps <- .qe_spacings(x)
  list(x = x, gaps = gaps, n = n, omitted = omitted, constant = constant,
       breaks = if (n > 1L) seq_len(n - 1L) / n else numeric())
}

# Ratios of partial deviations depend only on relative spacings. Scaling
# spacings (rather than the data) preserves small differences at large offsets.
.qe_spacings <- function(x) {
  gaps <- diff(x)
  if (any(!is.finite(gaps))) {
    scale <- max(abs(x))
    overflow <- !is.finite(gaps)
    gaps[!overflow] <- gaps[!overflow] / scale
    gaps[overflow] <- (x[-1L] / scale - x[-length(x)] / scale)[overflow]
  } else {
    gaps <- gaps / max(gaps)
  }
  gaps
}

# Comparing against k/n avoids both multiplication roundoff at exact knots
# and tolerance rules that would absorb a distinct probability just above one.
.qe_ranks <- function(probs, sample, reflected = FALSE) {
  if (reflected) {
    sample$n - findInterval(probs, sample$breaks)
  } else {
    findInterval(probs, sample$breaks, left.open = TRUE) + 1L
  }
}

.qe_boot_args <- function(trim, B, seed) {
  .qe_number(trim, "trim", 0, 0.5, open = TRUE)
  .qe_number(B, "B", 1, .Machine$integer.max, integer = TRUE)
  if (!is.null(seed)) {
    .qe_number(seed, "seed", 0, .Machine$integer.max, integer = TRUE)
  }
}

# A supplied seed is local: do not perturb an analysis surrounding this call,
# including a session in which the RNG has not yet been initialized.
.qe_with_seed <- function(seed, code) {
  if (is.null(seed)) return(force(code))
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    if (!identical(RNGkind(), old_kind)) do.call(RNGkind, as.list(old_kind))
    if (had_seed) {
      assign(".Random.seed", old_seed, envir = .GlobalEnv)
    } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
      rm(".Random.seed", envir = .GlobalEnv)
    }
  }, add = TRUE)
  set.seed(seed)
  force(code)
}

.qe_no_dots <- function(...) {
  if (length(list(...))) stop("Unused arguments in `...`.", call. = FALSE)
}

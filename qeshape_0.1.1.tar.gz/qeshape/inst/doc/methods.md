# Methods and relationship to the manuscript

This guide documents `qeshape` 0.1.1, accompanying Guanjie Lyu (2026),
*Quantile–expectile calibration curves for distributional shape:
estimation, inference, and symmetry testing*, unpublished manuscript.
The manuscript and its archived replication programs remain the sources
for the theoretical results and the reported simulation experiments.

## Calibration and asymmetry

Given observations `x[1], ..., x[n]`, the empirical left quantile is
`q(p) = x[ceiling(n * p)]` after sorting. The implementation compares
probabilities directly with the represented breakpoints `k/n`, avoiding
a potentially rounded multiplication `n * p`. An exact supplied `k/n`
selects the `k`th order statistic, while a larger representable probability
selects the next cell. Reflected quantile ranks are computed against the
same probability grid to avoid cancellation from forming `1 - p`.

The lower and upper hinge averages are

```text
L(p) = mean(pmax(q(p) - x, 0))
U(p) = mean(pmax(x - q(p), 0))
tau(p) = L(p) / (L(p) + U(p)).
```

`qe_curve()` evaluates `tau` and the quantiles at requested probabilities.
For a constant sample it returns `tau = 0.5` at every probability. The
calibration curve is unchanged by a positive affine transformation of
the observations. Hinge calculations use forward and reverse cumulative
adjacent spacings, scaled before accumulation to limit overflow and
cancellation. Reported quantiles use the original data scale. Numerical
accuracy remains limited by the precision of the supplied observations.
Each bootstrap draw rescales the spacings on its own positive-count
support, so omitting an extreme observation does not leave the remaining
observations on an unnecessarily small working scale.

`qe_asymmetry()` evaluates

```text
D(p) = tau(p) + tau(1 - p) - 1,   0 < p <= 1/2.
```

For a shape-regular population distribution, the curve is zero under
symmetry. Shape regularity means a nondegenerate distribution with finite
first moment whose quantile function is strictly increasing and locally
absolutely continuous on `(0, 1)`. On this class, the global zero-curve
condition characterizes symmetry. An exactly symmetric finite sample can
still have nonzero empirical asymmetry at probability breakpoints because
the empirical left quantile has jumps.
Restricting `D` to a trimmed interval only tests departures visible in
that interval.

These functions return compact objects with ordinary S3 methods.
`as.data.frame()` returns one row per requested probability. `predict()`
computes exact empirical values at new probabilities from retained
sample information. Curve, asymmetry, and band objects therefore contain
the input observations, even though their printed summaries do not show
the sample.

## Simultaneous confidence bands

`qe_band(x, trim = e, conf.level = 1 - a)` covers the interval
`[e, 1 - e]`. For each empirical bootstrap sample it computes

```text
Z*(p) = sqrt(n) * (tau*(p) - tau(p))
S* = sup(abs(Z*(p))),   e <= p <= 1 - e.
```

Every calibration curve is constant on cells `(k/n, (k + 1)/n]`.
The supremum is therefore computed on the finite grid comprising both
trim endpoints and all interior `k/n`. It is exact for the empirical
step functions, up to floating-point arithmetic.

Let `c` be the empirical `conf.level` quantile of the `B` values of `S*`,
using `quantile(type = 1)`. The band is

```text
[max(0, tau(p) - c/sqrt(n)), min(1, tau(p) + c/sqrt(n))].
```

The returned object stores the full finite grid, `critical.value = c`,
`half.width = c/sqrt(n)`, and all bootstrap statistics. Predictions are
allowed throughout the fitted trim interval. These are simultaneous,
unstudentized bands. Clipping to `[0, 1]` leaves the theoretical coverage
event unchanged because the population calibration curve takes values
in that interval.

## Symmetry tests

For `p` in `[e, 1/2]`, the two observed statistics are

```text
CvM: n * integral(D(p)^2 dp)
KS:  sqrt(n) * sup(abs(D(p))).
```

The CvM integral uses weight one. Breakpoints are the trim endpoints and
interior `k/n`; each open cell's constant value is squared and multiplied
by its width. Endpoint values have zero integration measure. The KS
supremum includes every boundary value and every open-cell value,
including the possibly shortened first cell. This is mathematically
equivalent to evaluating the boundaries and an interior representative
such as a midpoint in each cell. The implementation obtains the open-cell
order-statistic ranks directly from the left boundaries, avoiding a
numerical midpoint that could round to an endpoint in a very short cell.
Both calculations capture the reflected quantile curve's opposite step
orientation, including values that may differ at breakpoints.

The bootstrap process is centered:

```text
W*(p) = sqrt(n) * (D*(p) - D(p)).
```

The bootstrap CvM and KS statistics are respectively the integral of
`W*(p)^2` and the supremum of `abs(W*(p))`. Each bootstrap draw resamples
the original empirical distribution. It does not impose symmetry or
estimate a symmetry center.

`qe_symmetry_test()` returns an `htest` object with p-value

```text
(1 + number of bootstrap statistics >= observed statistic) / (B + 1).
```

The attainable minimum is `1/(B + 1)`. Ties count as exceedances.
Floating-point rounding can otherwise split mathematical ties and change
the p-value after rescaling a sample. Comparisons therefore allow a tolerance
of `64 * .Machine$double.eps` on the dimensionless asymmetry-amplitude scale:
`sqrt(T / (n * (0.5 - trim)))` for CvM, and `T / sqrt(n)` for KS.
Subtract this tolerance from the observed amplitude, clip at zero, and
transform back to statistic units to obtain the returned `p.value.threshold`.
The exact implemented rule is
`(1 + sum(bootstrap.statistics >= p.value.threshold)) / (B + 1)`.
Observed and bootstrap statistics are retained without rounding. Scaling
the tolerance by the amplitude preserves meaningful comparisons when the
trim interval is very short; an absolute tolerance on the raw CvM statistic
would not do so. This convention cannot recover precision already lost in
the supplied observations.

This finite Monte Carlo correction avoids zero estimates but does not
give an exact finite-sample level guarantee. The manuscript's archived
simulation study uses uncorrected exceedance proportions; its application
uses the corrected convention. The package consistently uses the latter,
with the additional numerical-tie convention described above.

Choose `method` and `trim` before inspecting test results. The default is
CvM with `trim = 0.05`. The manuscript reports that its KS companion can
be conservative at the studied sample sizes. Rejecting when either of
several unadjusted tests rejects does not retain a nominal single-test
significance level.

## Assumptions and numerical behavior

The point estimates are defined for any nonempty finite real numeric
sample. Inference additionally requires at least two observations and a
nonconstant sample. The statistical theory assumes iid observations, a
finite second moment, and a continuously differentiable distribution
with strictly positive density on a neighborhood of the trimmed
quantile interval. Null test validity also uses the manuscript's shape
regularity assumption. Coverage and test calibration require continuity
and strict crossing at the limiting critical quantile. The trim is fixed,
deterministic, and strictly between zero and one half.

Ties are handled algebraically; this does not extend the asymptotic
guarantees to arbitrary discrete or rounded distributions. Bootstrap
resamples can themselves be constant; their calibration curves use the
same `0.5` convention as a constant original sample. The bootstrap
requires no density estimation or tuning bandwidth.

The functions validate their inputs. `na.rm = TRUE` removes `NA` and
`NaN` only; infinite values are always rejected. Probability order and
duplicates are preserved. Probabilities must lie strictly inside `(0, 1)`;
asymmetry probabilities must also be at most `0.5`.
For bands, a trim so small that `1 - trim` rounds to `1` is rejected,
because it cannot form an interior endpoint in double precision.

With `seed = NULL`, the bootstrap advances the caller's RNG stream.
With a seed, the call temporarily sets the seed and restores the prior
`.Random.seed` and RNG kind on exit, including when an error occurs. If
`.Random.seed` was absent before the call, it is removed afterward.
R's `"Box-Muller"` normal generator also keeps a cached normal draw outside
`.Random.seed`, which the call cannot restore. The default `"Inversion"`
normal generator avoids that cache; use `seed = NULL` if continuation of
an existing Box-Muller cache is needed. The package uses sequential
bootstrap draws and has no parallel-backend dependency. Results need not
match the replication scripts bit for bit because their random-number
streams and resampling implementation may differ.

## Paper and replication-code map

| Package entry point | Manuscript topic | Related replication script |
|:---|:---|:---|
| `qe_curve()` | Section 2 calibration; Section 3 empirical estimation | `run_paper_simulations.R` |
| `qe_band()` | Section 3 empirical bootstrap and simultaneous bands | `run_band_coverage_simulation.R` |
| `qe_asymmetry()` | Section 4 reflected calibration and symmetry | `run_symmetry_test_simulation.R` |
| `qe_symmetry_test()` | Section 4 centered bootstrap CvM and KS tests | `run_symmetry_test_simulation.R` |
| Curve and band plots | Graphical comparisons and application | `run_graphical_comparison_simulation.R`, `run_actuarial_application.R` |

The package intentionally contains the reusable statistical methods.
Competitor methods, full simulation designs, empirical-null power
adjustments, application data, and publication tables remain in `R_code`.
Separate confidence bands for two samples do not provide a calibrated
test of equality between their calibration curves.

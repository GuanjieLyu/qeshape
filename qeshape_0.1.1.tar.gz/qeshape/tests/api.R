library(qeshape)

# Local seeding must preserve the surrounding stream under nondefault RNG
# settings as well as R's defaults. Compare subsequent draws with a control
# that made no package call; checking .Random.seed alone is not sufficient.
check_rng <- function() {
  original_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(original_kind)), add = TRUE)
  x <- c(-3, 0, 0, 2, 7)
  for (normal in c("Inversion", "Kinderman-Ramage")) {
    RNGkind("L'Ecuyer-CMRG", normal.kind = normal)
    set.seed(517)
    invisible(rnorm(7))
    expected <- c(runif(7), rnorm(7))
    set.seed(517)
    invisible(rnorm(7))
    before <- .Random.seed
    before_kind <- RNGkind()
    for (fun in list(qe_band, qe_symmetry_test)) {
      first <- fun(x, B = 7, seed = 23)
      second <- fun(x, B = 7, seed = 23)
      stopifnot(identical(first$bootstrap.statistics,
                          second$bootstrap.statistics),
                identical(.Random.seed, before),
                identical(RNGkind(), before_kind))
    }
    stopifnot(identical(c(runif(7), rnorm(7)), expected))

    for (fun in list(qe_band, qe_symmetry_test)) {
      rm(".Random.seed", envir = .GlobalEnv)
      invisible(fun(x, B = 7, seed = 23))
      stopifnot(!exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE),
                identical(RNGkind(), before_kind))
      set.seed(517)
      before <- .Random.seed
      invisible(fun(x, B = 7))
      stopifnot(!identical(.Random.seed, before),
                identical(RNGkind(), before_kind))
    }
  }
}
check_rng()

# Inspectors preserve fitted objects, including retained sample information.
# Single-probability plots exercise the no-interval boundary case.
check_methods <- function() {
  x <- c(-3, 0, 0, 2, 7)
  fits <- list(qe_curve(x, c(0.8, 0.2, 0.8)),
               qe_asymmetry(x, c(0.5, 0.2, 0.5)),
               qe_curve(x, 0.5), qe_asymmetry(x, 0.5),
               qe_curve(2, 0.25), qe_asymmetry(2, 0.25),
               qe_band(x, B = 7, seed = 23))
  graphic <- tempfile(fileext = ".pdf")
  grDevices::pdf(graphic)
  on.exit({
    grDevices::dev.off()
    unlink(graphic)
  }, add = TRUE)
  for (fit in fits) {
    before <- serialize(fit, NULL)
    invisible(capture.output(printed <- withVisible(print(fit))))
    plotted <- withVisible(plot(fit, axes = FALSE, xlim = c(0, 1),
                                ylim = c(-1, 1), main = "Custom title"))
    stopifnot(!printed$visible, identical(printed$value, fit),
              !plotted$visible, identical(plotted$value, fit))
    frame <- as.data.frame(fit)
    stopifnot(identical(frame$probability, fit$probabilities))
    prediction <- predict(fit)
    expected <- if (inherits(fit, "qe_band")) frame else
      if (inherits(fit, "qe_asymmetry")) fit$asymmetry else fit$calibration
    stopifnot(identical(prediction, expected),
              identical(serialize(fit, NULL), before))
  }
}
check_methods()

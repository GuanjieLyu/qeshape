library(qeshape)

# These tests use the defining hinge expectations and explicitly expanded
# bootstrap samples. They deliberately do not call package-internal helpers.
near <- function(actual, expected, tolerance = 1e-11) {
  stopifnot(isTRUE(all.equal(unname(actual), unname(expected),
                            tolerance = tolerance, check.attributes = FALSE)))
}
fails <- function(expr) {
  stopifnot(inherits(tryCatch(force(expr), error = identity), "error"))
}

direct_hinges <- function(x, ranks) {
  y <- sort(x)
  if (length(unique(y)) == 1L) return(rep(0.5, length(ranks)))
  # Scaling prevents overflow in the independent, quadratic-time hinge oracle.
  y <- y / max(abs(y))
  vapply(y[ranks], function(q) {
    lo <- sum(pmax(q - y, 0))
    up <- sum(pmax(y - q, 0))
    lo / (lo + up)
  }, numeric(1L))
}
direct_tau <- function(x, p) {
  n <- length(x)
  boundaries <- if (n > 1L) seq_len(n - 1L) / n else numeric()
  ranks <- vapply(p, function(u) 1L + sum(u > boundaries), integer(1L))
  direct_hinges(x, ranks)
}
direct_d <- function(x, p) {
  n <- length(x)
  boundaries <- if (n > 1L) seq_len(n - 1L) / n else numeric()
  reflected <- vapply(p, function(u) n - sum(u >= boundaries), integer(1L))
  direct_tau(x, p) + direct_hinges(x, reflected) - 1
}

# Every open cell and every boundary is evaluated separately. For an open
# cell, count knots at or below its left boundary: this remains meaningful
# even if no floating-point number lies strictly inside that cell.
partition <- function(n, trim, upper = 0.5) {
  boundaries <- (seq_len(n - 1L)) / n
  boundaries <- sort(unique(c(trim, boundaries[boundaries > trim &
                                               boundaries < upper], upper)))
  list(boundaries = boundaries,
       left = head(boundaries, -1L),
       widths = diff(boundaries))
}
direct_statistics <- function(x, trim, baseline = NULL) {
  n <- length(x)
  cells <- partition(n, trim)
  knots <- seq_len(n - 1L) / n
  lower <- vapply(cells$left, function(u) 1L + sum(knots <= u), integer(1L))
  upper <- n + 1L - lower
  d_boundary <- direct_d(x, cells$boundaries)
  d_inside <- direct_hinges(x, lower) + direct_hinges(x, upper) - 1
  if (!is.null(baseline)) {
    d_boundary <- d_boundary - direct_d(baseline, cells$boundaries)
    d_inside <- d_inside -
      (direct_hinges(baseline, lower) + direct_hinges(baseline, upper) - 1)
  }
  c(cvm = n * sum(cells$widths * d_inside^2),
    ks = sqrt(n) * max(abs(c(d_boundary, d_inside))))
}
expanded_bootstrap <- function(x, B, seed) {
  set.seed(seed)
  counts <- stats::rmultinom(B, length(x), rep(1 / length(x), length(x)))
  lapply(seq_len(B), function(b) rep(sort(x), counts[, b]))
}

# Point estimates: ties, unsorted probabilities, duplicate probabilities,
# endpoint ranks, and the defining finite-sample convention.
x <- c(7, -3, 0, 0, 2, 11, -1, 4)
p <- c(0.9, 0.125, 0.5, 0.125, 0.999, 0.001, 0.25)
fit <- qe_curve(x, p)
stopifnot(inherits(fit, "qe_curve"), fit$n == length(x), fit$omitted == 0L)
near(fit$probabilities, p)
near(fit$calibration, direct_tau(x, p))
near(fit$quantiles, stats::quantile(x, p, type = 1, names = FALSE))
stopifnot(identical(names(as.data.frame(fit)),
                    c("probability", "quantile", "calibration")))
near(as.data.frame(fit)$calibration, fit$calibration)
near(stats::predict(fit, c(0.03, 0.31, 0.67)),
     direct_tau(x, c(0.03, 0.31, 0.67)))
near(qe_curve(rev(x), p)$calibration, fit$calibration)
near(qe_curve(12 + 3.5 * x, p)$calibration, fit$calibration)
stopifnot(all(diff(qe_curve(x)$calibration) >= -1e-13),
          all(fit$calibration >= 0), all(fit$calibration <= 1))
near(qe_curve(5, c(0.01, 0.5, 0.99))$calibration, rep(0.5, 3))
near(qe_curve(rep(-7, 4), p)$calibration, rep(0.5, length(p)))
near(qe_curve(rep(-7, 4), p)$quantiles, rep(-7, length(p)))
near(qe_asymmetry(rep(-7, 4), c(0.1, 0.5))$asymmetry, c(0, 0))

# The empirical median is the lower order statistic for even n. A symmetric
# sample therefore need not have zero asymmetry at individual rank boundaries.
symmetric <- c(-3, -1, 1, 3)
near(qe_asymmetry(symmetric, 0.5)$asymmetry, -0.5)
asym <- qe_asymmetry(x, c(0.05, 0.125, 0.3, 0.5))
stopifnot(inherits(asym, "qe_asymmetry"), asym$n == length(x))
near(asym$asymmetry, direct_d(x, asym$probabilities))
stopifnot(identical(names(as.data.frame(asym)), c("probability", "asymmetry")))
near(stats::predict(asym, c(0.08, 0.5)), direct_d(x, c(0.08, 0.5)))

# Decimal rank boundaries should survive floating-point representation. Even
# the next representable probability must retain the next order statistic.
rank_fit <- qe_curve(seq_len(100), c(0.58, 0.58 + 1e-16, 0.58 + 1e-12))
near(rank_fit$quantiles, c(58, 59, 59))
near(qe_curve(seq_len(7), c(1 / 7, 1 / 7 + 1e-16))$quantiles, c(1, 2))
near(qe_curve(seq_len(100))$quantiles, 5:95)
near(qe_asymmetry(seq_len(7), c(1 / 7, 1 / 7 + 1e-16))$asymmetry,
     direct_d(seq_len(7), c(1 / 7, 1 / 7 + 1e-16)))

# Stable arithmetic at tiny scales, enormous scales, and large locations.
wide <- c(-4, -1, 0, 0, 2, 5)
for (y in list(wide * 1e-300, wide * 1e307,
               1e150 + wide * 1e140, c(-1e308, 0, 1e308))) {
  extreme <- qe_curve(y, c(0.1, 0.4, 0.5, 0.9))
  stopifnot(all(is.finite(extreme$calibration)),
            all(is.finite(extreme$quantiles)))
  near(extreme$calibration, direct_tau(y, extreme$probabilities), 2e-6)
}
# These gaps are exactly representable despite the large offset. Raw partial
# sums lose enough precision here to alter the result, so use known answers.
near(qe_curve(1e16 + c(0, 2, 4, 8), c(0.25, 0.5, 0.75, 0.99))$calibration,
     c(0, 0.2, 0.6, 1))

# Missing observations are counted; non-finite observations are never silently
# removed. A single remaining observation is valid for point estimation.
missing_fit <- qe_curve(c(NA_real_, x, NaN), p, na.rm = TRUE)
stopifnot(missing_fit$n == length(x), missing_fit$omitted == 2L)
near(missing_fit$calibration, fit$calibration)
near(qe_curve(c(NA, 4), 0.5, na.rm = TRUE)$calibration, 0.5)

# Exact band grid, critical value, clipping, and the bootstrap distribution.
B <- 31L
seed <- 5241L
trim <- 0.13
samples <- expanded_bootstrap(x, B, seed)
band <- qe_band(x, trim = trim, conf.level = 0.9, B = B, seed = seed)
stopifnot(inherits(band, "qe_band"), inherits(band, "qe_curve"),
          band$B == B, band$n == length(x), band$omitted == 0L)
grid <- sort(unique(c(trim, 1 - trim,
                      (seq_len(length(x) - 1L) / length(x))[
                        seq_len(length(x) - 1L) / length(x) > trim &
                        seq_len(length(x) - 1L) / length(x) < 1 - trim])))
near(band$probabilities, grid)
near(band$calibration, direct_tau(x, grid))
boot_sup <- vapply(samples, function(y) {
  sqrt(length(x)) * max(abs(direct_tau(y, grid) - direct_tau(x, grid)))
}, numeric(1L))
near(band$bootstrap.statistics, boot_sup)
critical <- unname(stats::quantile(boot_sup, 0.9, type = 1))
near(band$critical.value, critical)
near(band$half.width, critical / sqrt(length(x)))
near(band$lower, pmax(0, band$calibration - band$half.width))
near(band$upper, pmin(1, band$calibration + band$half.width))
stopifnot(all(band$lower <= band$calibration),
          all(band$upper >= band$calibration))
band_frame <- as.data.frame(band)
stopifnot(all(c("probability", "quantile", "calibration", "lower", "upper") %in%
                names(band_frame)))
near(band_frame$lower, band$lower)
near(band_frame$upper, band$upper)
band_prediction <- stats::predict(band, c(trim, 0.37, 1 - trim))
stopifnot(is.data.frame(band_prediction),
          all(c("probability", "quantile", "calibration", "lower", "upper") %in%
                names(band_prediction)))
near(band_prediction$calibration, direct_tau(x, c(trim, 0.37, 1 - trim)))
near(band_prediction$lower,
     pmax(0, band_prediction$calibration - band$half.width))
near(band_prediction$upper,
     pmin(1, band_prediction$calibration + band$half.width))
near(qe_band(rev(x), trim = trim, conf.level = 0.9, B = B,
             seed = seed)$bootstrap.statistics, boot_sup)
near(qe_band(12 + 4 * x, trim = trim, conf.level = 0.9, B = B,
             seed = seed)$bootstrap.statistics, boot_sup)

# Both tests use an ordinary empirical bootstrap centered at the observed
# curve. Compare every replicate against expanded data and direct integrals.
for (y in list(x, c(-5, -2, 0, 0, 3, 4, 17), symmetric, c(0, 2))) {
  for (epsilon in c(0.05, 0.13, 0.25, 0.49)) {
    replicates <- expanded_bootstrap(y, B, seed)
    expected <- direct_statistics(y, epsilon)
    boot <- vapply(replicates, direct_statistics, numeric(2L),
                   trim = epsilon, baseline = y)
    for (method in c("cvm", "ks")) {
      test <- qe_symmetry_test(y, method = method, trim = epsilon,
                               B = B, seed = seed)
      stopifnot(inherits(test, "qe_symmetry_test"), inherits(test, "htest"),
                test$B == B, test$n == length(y))
      near(test$statistic, expected[method])
      near(test$bootstrap.statistics, boot[method, ])
      # Separate floating-point implementations may round a mathematical tie
      # differently. Away from ties the oracle determines p exactly; at ties
      # it supplies bounds, followed by an exact public-rule check below.
      lower_exceed <- sum(boot[method, ] > expected[method] + 1e-13)
      upper_exceed <- sum(boot[method, ] >= expected[method] - 1e-13)
      stopifnot(test$p.value >= (1 + lower_exceed) / (B + 1),
                test$p.value <= (1 + upper_exceed) / (B + 1))
      stopifnot(test$p.value > 0, test$p.value <= 1)
      # The reported cutoff exposes the numerical-tie convention for auditing.
      stopifnot(test$p.value.threshold >= 0,
                test$p.value.threshold <= unname(test$statistic))
      near(test$p.value,
           (1 + sum(test$bootstrap.statistics >= test$p.value.threshold)) /
             (B + 1))
    }
  }
}
near(qe_symmetry_test(symmetric, "cvm", B = 9, seed = 1)$statistic, 0)
near(qe_symmetry_test(symmetric, "ks", B = 9, seed = 1)$statistic, 1)
near(qe_symmetry_test(symmetric, "cvm", B = 9, seed = 1)$p.value, 1)

# A resample that omits a huge outlier still has its own distinct small-scale
# support. Normalizing all resamples by the original range would erase it.
multiscale <- c(0, 1e-100, 1e308)
adversarial_B <- 99L
adversarial_seed <- 1947L
adversarial_samples <- expanded_bootstrap(multiscale, adversarial_B,
                                          adversarial_seed)
omitted_outlier <- vapply(adversarial_samples, function(y) {
  max(y) < 1e308 && length(unique(y)) > 1L
}, logical(1L))
stopifnot(any(omitted_outlier))
adversarial_band <- qe_band(multiscale, B = adversarial_B, seed = adversarial_seed)
adversarial_sup <- vapply(adversarial_samples, function(y) {
  sqrt(3) * max(abs(direct_tau(y, adversarial_band$probabilities) -
                     direct_tau(multiscale, adversarial_band$probabilities)))
}, numeric(1L))
near(adversarial_band$bootstrap.statistics, adversarial_sup)
for (method in c("cvm", "ks")) {
  adversarial_fit <- qe_symmetry_test(multiscale, method, B = adversarial_B,
                                      seed = adversarial_seed)
  adversarial_boot <- vapply(adversarial_samples, function(y) {
    direct_statistics(y, 0.05, baseline = multiscale)[method]
  }, numeric(1L))
  near(adversarial_fit$bootstrap.statistics, adversarial_boot)
}

# The real open interval remains nonempty when a rounded numeric midpoint
# equals a boundary. Integral statistics use the cell's interior ranks.
for (tiny_trim in c(0.5 - .Machine$double.eps / 4,
                    0.25 - .Machine$double.eps / 8)) {
  tiny_samples <- expanded_bootstrap(symmetric, B, seed)
  tiny_boot <- vapply(tiny_samples, direct_statistics, numeric(2L),
                     trim = tiny_trim, baseline = symmetric)
  tiny_cvm <- qe_symmetry_test(symmetric, "cvm", trim = tiny_trim, B = B,
                               seed = seed)
  tiny_ks <- qe_symmetry_test(symmetric, "ks", trim = tiny_trim, B = B,
                              seed = seed)
  stopifnot(unname(tiny_cvm$statistic) == 0)
  near(tiny_ks$statistic, 1)
  # Normalize the integrals to prevent an absolute tolerance from hiding a
  # wrong answer on an interval only one representable number wide.
  near(tiny_cvm$bootstrap.statistics / (0.5 - tiny_trim),
       tiny_boot["cvm", ] / (0.5 - tiny_trim))
  near(tiny_ks$bootstrap.statistics, tiny_boot["ks", ])
}

for (method in c("cvm", "ks")) {
  reference <- qe_symmetry_test(x, method, B = B, seed = seed)
  transformed <- qe_symmetry_test(3 + 8 * x, method, B = B, seed = seed)
  near(reference$statistic, transformed$statistic)
  near(reference$bootstrap.statistics, transformed$bootstrap.statistics)
  near(qe_symmetry_test(rev(x), method, B = B,
                       seed = seed)$bootstrap.statistics,
       reference$bootstrap.statistics)
}

# With two observations, a bootstrap sample is often constant. It must use
# the same 1/2 calibration convention and produce finite inference results.
two_band <- qe_band(c(0, 2), B = 25, seed = 17)
two_test <- qe_symmetry_test(c(0, 2), B = 25, seed = 17)
stopifnot(all(is.finite(two_band$bootstrap.statistics)),
          all(is.finite(two_test$bootstrap.statistics)))
stopifnot(is.finite(qe_band(x, B = 1, seed = 3)$critical.value),
          qe_symmetry_test(x, B = 1, seed = 3)$p.value %in% c(0.5, 1))

# An explicit seed is local and reproducible. Without one, normal R stream
# advancement is retained. This also covers sessions with no .Random.seed.
set.seed(9001)
saved_state <- .Random.seed
saved_kind <- RNGkind()
invisible(qe_band(x, B = 7, seed = 1))
stopifnot(identical(saved_state, .Random.seed), identical(saved_kind, RNGkind()))
invisible(qe_symmetry_test(x, B = 7, seed = 1))
stopifnot(identical(saved_state, .Random.seed), identical(saved_kind, RNGkind()))
invisible(qe_symmetry_test(x, B = 7))
stopifnot(!identical(saved_state, .Random.seed), identical(saved_kind, RNGkind()))
rm(".Random.seed", envir = .GlobalEnv)
invisible(qe_band(x, B = 7, seed = 1))
stopifnot(!exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
invisible(qe_symmetry_test(x, B = 7, seed = 1))
stopifnot(!exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))

# Reject ambiguous coercions, invalid probability domains, and invalid
# inference settings. These tests assert behavior, not message wording.
for (bad in list(NULL, numeric(), "1", TRUE, 1 + 1i, factor("a"),
                 list(1, 2), matrix(1:4, 2), data.frame(x = 1:4),
                 c(1, NA), c(1, NaN), c(1, Inf), c(1, -Inf))) {
  fails(qe_curve(bad))
  fails(qe_asymmetry(bad))
}
for (bad in list(c(NA, NaN), c(1, Inf), c(1, -Inf))) {
  fails(qe_curve(bad, na.rm = TRUE))
}
for (bad in list(numeric(), 0, 1, -0.1, 1.1, NA_real_, Inf,
                 c(0.1, NaN), "0.5", TRUE, matrix(0.5))) {
  fails(qe_curve(x, bad))
  fails(stats::predict(fit, bad))
}
for (bad in list(0, 0.5001, NA_real_, Inf)) {
  fails(qe_asymmetry(x, bad))
  fails(stats::predict(asym, bad))
}
for (bad in list(1, c(1, 1, 1), numeric(), c(NA, NA))) {
  fails(qe_band(bad, B = 2))
  fails(qe_symmetry_test(bad, B = 2))
}
for (bad in list(0, 0.5, -0.01, NA_real_, Inf, c(0.1, 0.2))) {
  fails(qe_band(x, trim = bad, B = 2))
  fails(qe_symmetry_test(x, trim = bad, B = 2))
}
for (bad in list(0, -1, 1.5, Inf, NA_real_, c(2, 3))) {
  fails(qe_band(x, B = bad))
  fails(qe_symmetry_test(x, B = bad))
}
for (bad in list(0, 1, NA_real_, c(0.9, 0.95))) {
  fails(qe_band(x, conf.level = bad, B = 2))
}
fails(qe_symmetry_test(x, method = "unknown", B = 2))
fails(qe_band(x, trim = 1e-20, B = 2))
for (bad in list(-1, 1.5, NA_real_, Inf, c(1, 2), "1")) {
  fails(qe_band(x, seed = bad, B = 2))
  fails(qe_symmetry_test(x, seed = bad, B = 2))
}
fails(stats::predict(band, trim / 2))
fails(stats::predict(band, 1 - trim / 2))
fails(qe_curve(x, na.rm = NA))
fails(qe_curve(x, na.rm = c(TRUE, FALSE)))

# Base graphics and printing are part of the dependency-free public interface.
graphic <- tempfile(fileext = ".pdf")
grDevices::pdf(graphic)
plot(fit)
plot(asym)
plot(band)
grDevices::dev.off()
stopifnot(file.info(graphic)$size > 0)
unlink(graphic)
stopifnot(length(capture.output(print(fit))) > 0,
          length(capture.output(print(asym))) > 0,
          length(capture.output(print(band))) > 0,
          length(capture.output(print(two_test))) > 0)

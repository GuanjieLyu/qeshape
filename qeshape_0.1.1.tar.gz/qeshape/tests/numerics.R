library(qeshape)

# Exact small-sample oracles for mathematical bootstrap ties. All arithmetic
# in the comparisons below uses small integers, avoiding the floating-point
# comparison whose regression these tests detect.
B <- 199L
seed <- 31L
set.seed(seed)
counts_ks <- stats::rmultinom(B, 3L, rep(1 / 3, 3L))

# For sorted (-5, -3, 1), the calibration levels are (0, 1/3, 1).
# The observed KS / sqrt(3) is 2/3. Enumerating the three-observation
# multiplicities shows that every draw except (1, 1, 1) attains or exceeds
# this value: constant samples are ties, and two-point samples have their
# middle calibration level at an endpoint.
ks_expected <- (1 + sum(colSums(counts_ks == 1L) != 3L)) / (B + 1)

x_cvm <- c(-8, -2, -5, -6)
set.seed(seed)
counts_cvm <- stats::rmultinom(B, 4L, rep(1 / 4, 4L))
exceeds_cvm <- apply(counts_cvm, 2L, function(counts) {
  y <- rep(sort(x_cvm), counts)
  hinge_pair <- function(q) {
    lo <- sum(pmax(q - y, 0))
    up <- sum(pmax(y - q, 0))
    if (lo + up == 0) c(1, 2) else c(lo, lo + up)
  }
  a <- hinge_pair(y[2L])
  b <- hinge_pair(y[3L])
  # D on (1/4, 1/2) equals numerator / denominator. The observed
  # D is -1/7, so |D* + 1/7| >= 1/7 iff D* >= 0 or D* <= -2/7.
  # The outer cell has D = 0 for the original and every resample.
  numerator <- a[1L] * b[2L] + b[1L] * a[2L] - a[2L] * b[2L]
  denominator <- a[2L] * b[2L]
  numerator >= 0 || 7 * numerator <= -2 * denominator
})
cvm_expected <- (1 + sum(exceeds_cvm)) / (B + 1)

for (spec in list(list(x = c(1, -3, -5), method = "ks", p = ks_expected),
                  list(x = x_cvm, method = "cvm", p = cvm_expected))) {
  for (y in list(spec$x, 0.37 * spec$x, 11 + 7 * spec$x,
                 1e-200 * spec$x, 1e200 * spec$x)) {
    fit <- qe_symmetry_test(y, method = spec$method, B = B, seed = seed)
    stopifnot(fit$p.value == spec$p,
              fit$p.value.threshold <= unname(fit$statistic),
              fit$p.value.threshold >= 0)
  }
}

# The CvM p-value must preserve the same exact comparison when the final
# cell is only one representable probability wide. A fixed absolute
# tolerance on the raw statistic would incorrectly make the p-value one.
tiny_trim <- 0.5 - .Machine$double.eps / 4
for (y in list(x_cvm, 0.37 * x_cvm, 11 + 7 * x_cvm)) {
  fit <- qe_symmetry_test(y, "cvm", trim = tiny_trim, B = B, seed = seed)
  stopifnot(fit$p.value == cvm_expected, fit$p.value < 1,
            unname(fit$statistic) > 0,
            unname(fit$statistic) < .Machine$double.eps)
}
